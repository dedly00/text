export interface IGenerateNewCookies {
    textpro: {
        'user-agent': string;
        'cookie': string
    },
    ephoto: {
        'user-agent': string;
        'cookie': string;
    }
}
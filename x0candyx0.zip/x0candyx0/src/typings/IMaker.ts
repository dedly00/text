export interface IMaker {
    success: boolean;
    imageUrl: string;
    session_id: string;
}
import { Maker } from '../src';

new Maker().Ephoto360('https://en.ephoto360.com/create-colorful-angel-wing-avatars-731.html', ["Koja Babu"]).then(res => {
    console.log(res)
})
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const src_1 = require("../src");
new src_1.Maker().Ephoto360('https://en.ephoto360.com/create-colorful-angel-wing-avatars-731.html', ["Koja Babu"]).then(res => {
    console.log(res);
});
